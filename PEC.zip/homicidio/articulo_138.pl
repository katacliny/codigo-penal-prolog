:- dynamic(causa_muerte/2).

articulo_138_comete_delito_homicidio(Agresor, Agredido) :-
    causa_muerte(Agresor, Agredido).